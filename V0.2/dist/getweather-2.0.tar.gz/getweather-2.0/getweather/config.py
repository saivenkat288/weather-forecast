weather_url_start="http://api.openweathermap.org/data/2.5/forecast?q="
weather_url_end="&appid="
api_key="a8883fa2a01fbe108264efe57eedd136"